var searchData=
[
  ['bool_5fpayload_5fvec_409',['bool_payload_vec',['../structMessage.html#a04a2ef49dab64ad365bbf69da31f05bd',1,'Message']]],
  ['border_5ftiles_5fvec_410',['border_tiles_vec',['../classHexMap.html#af68c94aabde8a95456481bbb7f7aae6d',1,'HexMap']]]
];
