var searchData=
[
  ['demand_5fmwh_425',['demand_MWh',['../classGame.html#a373351cf0ae0b61d796effb4a116f778',1,'Game']]],
  ['double_5fpayload_5fvec_426',['double_payload_vec',['../structMessage.html#a16da4b3098ba28e1b4e1a210a167dd5a',1,'Message']]]
];
