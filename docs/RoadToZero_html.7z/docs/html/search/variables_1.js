var searchData=
[
  ['bool_5fpayload_484',['bool_payload',['../structMessage.html#a1c9dedc4e3523737f722b8e17263f06e',1,'Message']]],
  ['border_5ftiles_5fvec_485',['border_tiles_vec',['../classHexMap.html#af68c94aabde8a95456481bbb7f7aae6d',1,'HexMap']]],
  ['build_5fsettlement_5fcost_486',['BUILD_SETTLEMENT_COST',['../constants_8h.html#a1ccbf4b9df2b28aa6091eb88abd4c2c3',1,'constants.h']]]
];
