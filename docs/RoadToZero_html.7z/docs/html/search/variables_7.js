var searchData=
[
  ['has_5fimprovement_567',['has_improvement',['../classHexTile.html#ab01474f4e5105d2b9a0d1bb6bf95ae07',1,'HexTile']]],
  ['hex_5fdraw_5forder_5fvec_568',['hex_draw_order_vec',['../classHexMap.html#a6ee602c1fe9edb63a948897cc1538c80',1,'HexMap']]],
  ['hex_5fmap_569',['hex_map',['../classHexMap.html#a203bca7b5902259e8100fb11d6ef2a99',1,'HexMap']]],
  ['hex_5fmap_5fchannel_570',['HEX_MAP_CHANNEL',['../constants_8h.html#addf30cbde5d0378e84c97b75c27cd68c',1,'constants.h']]],
  ['hex_5fmap_5fptr_571',['hex_map_ptr',['../classGame.html#a100b4ba30fdbeaaa8cf0321edc38a269',1,'Game']]]
];
