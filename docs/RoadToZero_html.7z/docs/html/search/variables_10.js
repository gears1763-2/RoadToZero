var searchData=
[
  ['visual_5fscreen_515',['visual_screen',['../classContextMenu.html#af79909772ceef90a79c5985bcbe61ebc',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5fbottom_516',['visual_screen_frame_bottom',['../classContextMenu.html#a2cbec94e7c4379b1b6a67e3c45d321cf',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5fleft_517',['visual_screen_frame_left',['../classContextMenu.html#a6adf9424cd285aa5f34c62279a41430e',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5fright_518',['visual_screen_frame_right',['../classContextMenu.html#a75f321c71a0dd610dd3228c5d6fd1aa1',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5ftop_519',['visual_screen_frame_top',['../classContextMenu.html#a58f030bfe7b1da74c08c75491b5b822d',1,'ContextMenu']]]
];
