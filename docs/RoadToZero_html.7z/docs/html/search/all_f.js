var searchData=
[
  ['quit_5fgame_173',['quit_game',['../classGame.html#ad38676eabcf86f3c4cbb2e9ec8d29026',1,'Game']]]
];
