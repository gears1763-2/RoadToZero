var searchData=
[
  ['bibliography_8',['Bibliography',['../citelist.html',1,'']]]
];
