var searchData=
[
  ['n_5flayers_195',['n_layers',['../classHexMap.html#af9e0a39839146da5406ac01c39f047dc',1,'HexMap']]],
  ['node_5fsprite_196',['node_sprite',['../classHexTile.html#a137f08f6ab1b68072eb82df8e0b95918',1,'HexTile']]]
];
