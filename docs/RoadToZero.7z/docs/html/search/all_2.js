var searchData=
[
  ['bibliography_4',['Bibliography',['../citelist.html',1,'']]]
];
