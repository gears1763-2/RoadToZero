var searchData=
[
  ['n_5flayers_260',['n_layers',['../classHexMap.html#af9e0a39839146da5406ac01c39f047dc',1,'HexMap']]],
  ['n_5ftiles_261',['n_tiles',['../classHexMap.html#ab2d83b72890e60ee38ecd120900ea4f3',1,'HexMap']]],
  ['node_5fsprite_262',['node_sprite',['../classHexTile.html#a137f08f6ab1b68072eb82df8e0b95918',1,'HexTile']]]
];
