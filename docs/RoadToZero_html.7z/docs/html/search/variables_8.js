var searchData=
[
  ['int_5fpayload_540',['int_payload',['../structMessage.html#aaea3867fb5601800ca773f81cf87aef3',1,'Message']]],
  ['is_5fselected_541',['is_selected',['../classHexTile.html#a55521a7aa6aece3a27561e5e822819f4',1,'HexTile::is_selected()'],['../classTileImprovement.html#a72779a662dd4fcffb765a9bc480dc68d',1,'TileImprovement::is_selected()']]]
];
