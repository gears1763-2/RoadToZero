var searchData=
[
  ['just_5fbuilt_542',['just_built',['../classTileImprovement.html#a41ca476a8696322658a0b45122741350',1,'TileImprovement']]]
];
