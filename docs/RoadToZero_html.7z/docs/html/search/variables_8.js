var searchData=
[
  ['int_5fpayload_503',['int_payload',['../structMessage.html#aaea3867fb5601800ca773f81cf87aef3',1,'Message']]],
  ['is_5fselected_504',['is_selected',['../classHexTile.html#a55521a7aa6aece3a27561e5e822819f4',1,'HexTile']]]
];
