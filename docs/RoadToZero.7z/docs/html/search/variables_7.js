var searchData=
[
  ['major_5fradius_228',['major_radius',['../classHexTile.html#a25ca4334ee00dd562bf9032a6f438218',1,'HexTile']]],
  ['messages_5fhandler_5fptr_229',['messages_handler_ptr',['../classHexMap.html#a35cb4676b3ed0223966934a542292aed',1,'HexMap::messages_handler_ptr()'],['../classHexTile.html#aae08e6f4a10e64e6beedd5737c5dc04a',1,'HexTile::messages_handler_ptr()']]],
  ['minor_5fradius_230',['minor_radius',['../classHexTile.html#aca88c3ef6c6fdc5b9e675eba32715aa5',1,'HexTile']]]
];
