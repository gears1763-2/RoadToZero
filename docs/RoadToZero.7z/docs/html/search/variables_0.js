var searchData=
[
  ['assets_5fmanager_5fptr_181',['assets_manager_ptr',['../classHexMap.html#acb8b348c1867eb307c65b9a73fd218c1',1,'HexMap::assets_manager_ptr()'],['../classHexTile.html#a79977a4f558b36091ec460372c0c73e5',1,'HexTile::assets_manager_ptr()']]]
];
