var searchData=
[
  ['lake_661',['LAKE',['../HexTile_8h.html#ac9e486ec80ccfdb28a4f4837d419c9f1a3b1f4ff907193c7176661c58c5ed85f7',1,'HexTile.h']]],
  ['loss_5fcredits_662',['LOSS_CREDITS',['../Game_8h.html#a896617de6e1c82953f407789633057d8a967cf6a574bb9e2b65c5d85303f47099',1,'Game.h']]],
  ['loss_5fdemand_663',['LOSS_DEMAND',['../Game_8h.html#a896617de6e1c82953f407789633057d8a3f296e97da96201d36c8578dc1fa62a2',1,'Game.h']]],
  ['loss_5femissions_664',['LOSS_EMISSIONS',['../Game_8h.html#a896617de6e1c82953f407789633057d8aad57b8164eab90bd58d1533689adcf6b',1,'Game.h']]]
];
