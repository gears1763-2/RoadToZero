var searchData=
[
  ['victory_683',['VICTORY',['../Game_8h.html#a896617de6e1c82953f407789633057d8a38088c60165dc5b369946da1d8797d00',1,'Game.h']]]
];
