var searchData=
[
  ['population_524',['population',['../classGame.html#a659668162016db06211db6a14bd498ad',1,'Game::population()'],['../classSettlement.html#ab5266e73109effdf3fb0d4aa09d9448e',1,'Settlement::population()']]],
  ['position_5fx_525',['position_x',['../classContextMenu.html#a58fc8bb2cee4a89d378c3758459c03f5',1,'ContextMenu::position_x()'],['../classHexMap.html#a39772004bfdf516b14c257911231b771',1,'HexMap::position_x()'],['../classHexTile.html#af30fcbb2a8745e85df43f2f123f0301e',1,'HexTile::position_x()'],['../classTileImprovement.html#af35e2fefdbd35fd626da5572cc0d08aa',1,'TileImprovement::position_x()']]],
  ['position_5fy_526',['position_y',['../classContextMenu.html#a1423c1cdded57f849f70a6ae552656ca',1,'ContextMenu::position_y()'],['../classHexMap.html#a2195a8ac3aae5105443ee974d15b1eef',1,'HexMap::position_y()'],['../classHexTile.html#abb367c4218210afd4060bb95cb1e48fc',1,'HexTile::position_y()'],['../classTileImprovement.html#a1b075a677d1425e67433d401d5d04843',1,'TileImprovement::position_y()']]]
];
