var searchData=
[
  ['visual_5fscreen_5fframe_5fgrey_292',['VISUAL_SCREEN_FRAME_GREY',['../constants_8h.html#a4517e307ac1b6bda9c8ad3b8fbf353a3',1,'constants.h']]]
];
