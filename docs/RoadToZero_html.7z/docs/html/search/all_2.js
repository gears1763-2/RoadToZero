var searchData=
[
  ['below_5faverage_55',['BELOW_AVERAGE',['../HexTile_8h.html#a0b7350480ef72674136d97aa49df2906af6175682294cf5894769252a9cb63162',1,'HexTile.h']]],
  ['bibliography_56',['Bibliography',['../citelist.html',1,'']]],
  ['bool_5fpayload_5fvec_57',['bool_payload_vec',['../structMessage.html#a04a2ef49dab64ad365bbf69da31f05bd',1,'Message']]],
  ['border_5ftiles_5fvec_58',['border_tiles_vec',['../classHexMap.html#af68c94aabde8a95456481bbb7f7aae6d',1,'HexMap']]]
];
