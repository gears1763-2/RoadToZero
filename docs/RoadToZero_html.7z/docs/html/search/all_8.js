var searchData=
[
  ['has_5fimprovement_142',['has_improvement',['../classHexTile.html#ab01474f4e5105d2b9a0d1bb6bf95ae07',1,'HexTile']]],
  ['hastraffic_143',['hasTraffic',['../classMessageHub.html#a304a94ece03cb95945e31d90ce66798d',1,'MessageHub']]],
  ['hex_5fdraw_5forder_5fvec_144',['hex_draw_order_vec',['../classHexMap.html#a6ee602c1fe9edb63a948897cc1538c80',1,'HexMap']]],
  ['hex_5fmap_145',['hex_map',['../classHexMap.html#a203bca7b5902259e8100fb11d6ef2a99',1,'HexMap']]],
  ['hex_5fmap_5fchannel_146',['HEX_MAP_CHANNEL',['../constants_8h.html#addf30cbde5d0378e84c97b75c27cd68c',1,'constants.h']]],
  ['hex_5fmap_5fptr_147',['hex_map_ptr',['../classGame.html#a100b4ba30fdbeaaa8cf0321edc38a269',1,'Game']]],
  ['hexmap_148',['HexMap',['../classHexMap.html',1,'HexMap'],['../classHexMap.html#a2df9bab23e891932eb158433a5b6be5f',1,'HexMap::HexMap()']]],
  ['hexmap_2ecpp_149',['HexMap.cpp',['../HexMap_8cpp.html',1,'']]],
  ['hexmap_2eh_150',['HexMap.h',['../HexMap_8h.html',1,'']]],
  ['hextile_151',['HexTile',['../classHexTile.html',1,'HexTile'],['../classHexTile.html#aff4be6bd13084aa306b4398ae3ac0293',1,'HexTile::HexTile()']]],
  ['hextile_2ecpp_152',['HexTile.cpp',['../HexTile_8cpp.html',1,'']]],
  ['hextile_2eh_153',['HexTile.h',['../HexTile_8h.html',1,'']]]
];
