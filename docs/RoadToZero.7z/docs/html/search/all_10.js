var searchData=
[
  ['reroll_93',['reroll',['../classHexMap.html#a364676c1df8755df083a79238880e514',1,'HexMap']]],
  ['reset_94',['reset',['../classInputsHandler.html#a2ff0ef77b158e370e4e1d486d0b8c470',1,'InputsHandler']]]
];
