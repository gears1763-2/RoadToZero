var searchData=
[
  ['settlement_674',['SETTLEMENT',['../TileImprovement_8h.html#a7098d57f80dbc83d3aff78e14595e7baadcffb98d0e3eb7e3ceb9c05ba1d3465d',1,'TileImprovement.h']]],
  ['solar_5fpv_675',['SOLAR_PV',['../TileImprovement_8h.html#a7098d57f80dbc83d3aff78e14595e7baa52187a80542942cf3a4a226ed016c17e',1,'TileImprovement.h']]],
  ['system_5fmanagement_676',['SYSTEM_MANAGEMENT',['../Game_8h.html#a896617de6e1c82953f407789633057d8aa3bff63de5255a8c5828485e33d4df74',1,'Game.h']]]
];
