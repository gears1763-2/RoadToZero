var searchData=
[
  ['below_5faverage_652',['BELOW_AVERAGE',['../HexTile_8h.html#a0b7350480ef72674136d97aa49df2906af6175682294cf5894769252a9cb63162',1,'HexTile.h']]],
  ['build_5fsettlement_653',['BUILD_SETTLEMENT',['../Game_8h.html#a896617de6e1c82953f407789633057d8a6690c20252bb3d82b9480d8446fb0d79',1,'Game.h']]]
];
