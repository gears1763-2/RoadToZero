var searchData=
[
  ['demand_5fmwh_444',['demand_MWh',['../classGame.html#aef568e23bb6afd882d503afb6b31b643',1,'Game']]],
  ['double_5fpayload_445',['double_payload',['../structMessage.html#a3fe7ad49f7bd9eace8603a181deb1a95',1,'Message']]]
];
