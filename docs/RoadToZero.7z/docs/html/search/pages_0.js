var searchData=
[
  ['bibliography_264',['Bibliography',['../citelist.html',1,'']]]
];
