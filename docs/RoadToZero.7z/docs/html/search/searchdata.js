var indexSectionsWithContent =
{
  0: "_bcdefikmprst~",
  1: "i",
  2: "cdit",
  3: "_eimprt~",
  4: "fks",
  5: "f",
  6: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

