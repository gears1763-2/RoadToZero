var searchData=
[
  ['bibliography_1',['Bibliography',['../citelist.html',1,'']]]
];
