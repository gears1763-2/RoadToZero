var searchData=
[
  ['bibliography_9',['Bibliography',['../citelist.html',1,'']]]
];
