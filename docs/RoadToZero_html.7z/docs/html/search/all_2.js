var searchData=
[
  ['below_5faverage_72',['BELOW_AVERAGE',['../HexTile_8h.html#a0b7350480ef72674136d97aa49df2906af6175682294cf5894769252a9cb63162',1,'HexTile.h']]],
  ['bibliography_73',['Bibliography',['../citelist.html',1,'']]],
  ['bool_5fpayload_74',['bool_payload',['../structMessage.html#a1c9dedc4e3523737f722b8e17263f06e',1,'Message']]],
  ['border_5ftiles_5fvec_75',['border_tiles_vec',['../classHexMap.html#af68c94aabde8a95456481bbb7f7aae6d',1,'HexMap']]],
  ['build_5fmenu_5fopen_76',['build_menu_open',['../classHexTile.html#a83f7a24bfcf673aee4b236472a22062f',1,'HexTile']]],
  ['build_5fsettlement_77',['BUILD_SETTLEMENT',['../Game_8h.html#a896617de6e1c82953f407789633057d8a6690c20252bb3d82b9480d8446fb0d79',1,'Game.h']]],
  ['build_5fsettlement_5fcost_78',['BUILD_SETTLEMENT_COST',['../constants_8h.html#a1ccbf4b9df2b28aa6091eb88abd4c2c3',1,'constants.h']]]
];
