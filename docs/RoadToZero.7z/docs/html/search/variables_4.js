var searchData=
[
  ['major_5fradius_154',['major_radius',['../classHexTile.html#a25ca4334ee00dd562bf9032a6f438218',1,'HexTile']]],
  ['minor_5fradius_155',['minor_radius',['../classHexTile.html#aca88c3ef6c6fdc5b9e675eba32715aa5',1,'HexTile']]]
];
