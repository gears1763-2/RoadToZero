var searchData=
[
  ['hex_5fmap_304',['hex_map',['../classHexMap.html#a203bca7b5902259e8100fb11d6ef2a99',1,'HexMap']]],
  ['hex_5fmap_5fptr_305',['hex_map_ptr',['../classGame.html#a100b4ba30fdbeaaa8cf0321edc38a269',1,'Game']]]
];
