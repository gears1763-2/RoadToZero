var searchData=
[
  ['plains_425',['PLAINS',['../HexTile_8h.html#ac9e486ec80ccfdb28a4f4837d419c9f1aa2ea31a399f98e12824121ee15aaea6a',1,'HexTile.h']]],
  ['poor_426',['POOR',['../HexTile_8h.html#a0b7350480ef72674136d97aa49df2906aa0e7b099de4feb6f0886e89be7c470ca',1,'HexTile.h']]]
];
