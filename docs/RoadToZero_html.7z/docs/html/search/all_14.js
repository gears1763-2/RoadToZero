var searchData=
[
  ['victory_319',['VICTORY',['../Game_8h.html#a896617de6e1c82953f407789633057d8a38088c60165dc5b369946da1d8797d00',1,'Game.h']]],
  ['visual_5fscreen_320',['visual_screen',['../classContextMenu.html#af79909772ceef90a79c5985bcbe61ebc',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5fbottom_321',['visual_screen_frame_bottom',['../classContextMenu.html#a2cbec94e7c4379b1b6a67e3c45d321cf',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5fgrey_322',['VISUAL_SCREEN_FRAME_GREY',['../constants_8h.html#a4517e307ac1b6bda9c8ad3b8fbf353a3',1,'constants.h']]],
  ['visual_5fscreen_5fframe_5fleft_323',['visual_screen_frame_left',['../classContextMenu.html#a6adf9424cd285aa5f34c62279a41430e',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5fright_324',['visual_screen_frame_right',['../classContextMenu.html#a75f321c71a0dd610dd3228c5d6fd1aa1',1,'ContextMenu']]],
  ['visual_5fscreen_5fframe_5ftop_325',['visual_screen_frame_top',['../classContextMenu.html#a58f030bfe7b1da74c08c75491b5b822d',1,'ContextMenu']]]
];
