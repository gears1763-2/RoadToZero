var searchData=
[
  ['int_5fpayload_5fvec_306',['int_payload_vec',['../structMessage.html#af45fec23d4cbd23d4f0287004ab113ef',1,'Message']]],
  ['is_5fselected_307',['is_selected',['../classHexTile.html#a55521a7aa6aece3a27561e5e822819f4',1,'HexTile']]]
];
