var searchData=
[
  ['below_5faverage_36',['BELOW_AVERAGE',['../HexTile_8h.html#a0b7350480ef72674136d97aa49df2906af6175682294cf5894769252a9cb63162',1,'HexTile.h']]],
  ['bibliography_37',['Bibliography',['../citelist.html',1,'']]],
  ['border_5ftiles_5fvec_38',['border_tiles_vec',['../classHexMap.html#af68c94aabde8a95456481bbb7f7aae6d',1,'HexMap']]]
];
